

# API: 4w0ftznmvnvi

# https://pdftables.com/

install.packages("pdftables")

library(pdftables)

convert_pdf('Ndor942015AJEA19637.pdf', 
            output_file = NULL, 
            format = "xlsx-single", 
            message = TRUE, api_key = "n6st4mymjxge")

get_remaining("2tmxuawoafqu")


# https://journalofscience.ou.edu.vn/index.php/tech-en/article/view/2116/1720

?convert_pdf


convert_pdf("Ndor942015AJEA19637.pdf", "test2.csv", api_key = "4w0ftznmvnvi")
